/** Automatically generated file. DO NOT MODIFY */
package com.success_v1.successCar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}