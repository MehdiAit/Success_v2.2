package com.success_v1.agence;

public class Ville {
	
	String num_ville;
	String nom_ville;
	
	public Ville(String num, String nom)
	{
		this.num_ville = num;
		this.nom_ville = nom;
	}
	
	public Ville()
	{
		
	}

}
