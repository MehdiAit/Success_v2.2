package com.success_v1.agence;

public class Agence {
	
	String id;
	String nom;
	String adresse;
	
	public Agence (String nm, String det, String adr)
	{
		id = nm;
		nom = det;
		adresse=adr;
		
	}
	public Agence()
	{
		
	}

}
